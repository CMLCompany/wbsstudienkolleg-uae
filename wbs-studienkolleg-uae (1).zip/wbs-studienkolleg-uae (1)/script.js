/**
 * WBS-Studienkolleg UAE — Minimal Vanilla JavaScript
 * Lightweight, zero dependencies, no console errors.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Configurable UAE WhatsApp details (placeholders can be updated here)
  const UAE_WHATSAPP_CONFIG = {
    number: '+971500000000',
    message: encodeURIComponent('Hello WBS-Studienkolleg UAE, I would like to inquire about Studienkolleg in Germany.')
  };

  // WhatsApp click handler
  const whatsappLink = document.getElementById('uaeWhatsappLink');
  if (whatsappLink) {
    whatsappLink.addEventListener('click', (e) => {
      e.preventDefault();
      const cleanNumber = UAE_WHATSAPP_CONFIG.number.replace(/[^0-9]/g, '');
      const url = `https://wa.me/${cleanNumber}?text=${UAE_WHATSAPP_CONFIG.message}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    });
  }

  // Smooth scroll for internal anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId && targetId !== '#') {
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          e.preventDefault();
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    });
  });
});
